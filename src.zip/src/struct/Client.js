const {Client, Intents, Collection} = require('discord.js')
const Utils = require('../utils/Utils')
const config = require('../config')
const Erela = require('./Erela')
const ytsr = require('ytsr')
module.exports = class MusicBot extends Client {
    constructor(options = {}) {
        super({
            intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_VOICE_STATES, Intents.FLAGS.GUILD_MESSAGES]
        })
        this.config = config
        this.utils = new Utils(this)
        this.events = new Collection();
        this.commands = new Collection();
        this.aliases = new Collection();
        this.ytsr = ytsr
        //let create the manager
        /**
         * @type {Erela}
         */
        this.music = new Erela(this)
        this.on('raw', (d)=> this.music.manager.updateVoiceState(d))
    }

    async start() {
        await this.utils.loadCommands()
        await this.utils.loadEvents()
        this.music.build()
        await super.login(this.config.TOKEN)
    }

}