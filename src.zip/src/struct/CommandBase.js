//this is the template for commands
const Command = require("../../struct/Commands");
module.exports = new Command({
    name: '',
    aliases: [''],
    description: '',
    usage: '<>',
    cd: 10,
    async run (message, args, client) {
        //here will run the command
        
    }  
})