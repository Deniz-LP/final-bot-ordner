const Event = require("../struct/Events");
const { Message } = require('discord.js')
module.exports = class ready extends Event {
    constructor(...args) {
        super(...args, {
            once: false
        });
    }
    /**
     * 
     * @param {Message} message 
     */
    async run(message) {
        if (message.author.bot) return

        //this will be the command handler

        //this is to make pople mention the bot as prefix is useful.
        const mentionRegex = RegExp(`^<@!?${this.client.user.id}>$`);
        const mentionRegexPrefix = RegExp(`^<@!?${this.client.user.id}> `);

        let pref = this.client.config.PREFIX;

        if (message.content.match(mentionRegex)) message.reply({content: `My prefix is ${pref}`})

        const prefix = message.content.match(mentionRegexPrefix) ? message.content.match(mentionRegexPrefix)[0] : pref

        if (message.content.toLowerCase().startsWith(prefix)) {

            let [command, ...args] = message.content.substring(prefix.length).split(/ +/);
            
            let cmd = this.client.commands.get(command.toLowerCase()) || this.client.commands.get(this.client.aliases.get(command.toLowerCase()))

            if (cmd) {
                try{
                    cmd.run(message, args, this.client)
                }catch (e) {
                    console.log(e)
                }
            }
        }
    }
}