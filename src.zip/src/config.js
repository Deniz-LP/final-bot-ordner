exports.TOKEN = 'ODA3MzczOTgyNDExNTIyMDgw.YB3DnQ.az-wjyEsvyUEjI-VgYhwU5OTOK8'
exports.PREFIX = '?'