const { MessageEmbed } = require("discord.js");
const Command = require("../../struct/Commands");
module.exports = new Command({
    name: 'skip',
    aliases: [''],
    description: 'skip the song',
    usage: '',
    cd: 10,
    async run (message, args, client) {
        let pl = client.music.manager.get(message.guild.id);
        if (!pl) return message.reply({content: 'Play some music'})
        if (!pl.queue.size) return message.reply({content: 'There is nothing in the queue'})
        if (pl.queue.size < args[0]) return message.reply({content: 'This number is not in the queue range'})

        pl.stop(args[0] || 0)
    }  
})