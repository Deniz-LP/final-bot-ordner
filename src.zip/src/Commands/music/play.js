const { MessageEmbed } = require("discord.js");
const Command = require("../../struct/Commands");
module.exports = new Command({
    name: 'play',
    aliases: ['p'],
    description: 'play a song',
    usage: '<song>',
    cd: 10,
    async run (message, args, client) {

        //check if the user is in a vc
        if (!message.member.voice.channel) return message.reply({content: "You need to be ina vc"})
        let res;
        try {
            let url;
            if (!args[0].startsWith('http')) url = await client.ytsr(args.join(' '), {limit: 1});
            res = await client.music.manager.search({
                query: url?.items[0]?.url || args.join(' '),
                source: "youtube"
            }, message.author);
            if (res.loadType === "LOAD_FAILED") throw res.exception;
            if (res.loadType === 'NO_MATCHES') return message.reply({content: 'No matches'})
        }catch (err) {
            return message.reply(`An error ocurred: ${err.message}`);
        }

        const player = client.music.manager.create({
            guild: message.guild.id,
            voiceChannel: message.member.voice.channel.id,
            textChannel: message.channel.id,
            selfDeafen: true,
            volume: 100
        });
        //this will only run if you send a full playlist
        if (res.loadType === 'PLAYLIST_LOADED') {
            if (player.state !== 'CONNECTED') player.connect();
            let time = 0 + res.tracks[0].duration
            player.queue.add(res.tracks[0]);
            if (!player.playing && !player.paused && !player.queue.size) player.play();
            res.tracks.shift();
            res.tracks.forEach(song=> {
                time += song.duration
                player.queue.add(song)
            })
            let embed = new MessageEmbed();
            let t = client.utils.parseMs(time);
            embed.setAuthor({name: client.user.username, iconURL: client.user.avatarURL()})
            embed.addField(`Total Songs: ${player.queue.size}`, `Estimated time ${t.hours}H:${t.minutes}M`)
            embed.setColor('RANDOM')
            embed.setDescription(`Adding **${res.tracks.length}** songs of the playlist ${res.playlist.name}`)

            return message.channel.send({embeds: [embed]})
        }

        if (player.state !== 'CONNECTED') player.connect()
        player.queue.add(res.tracks[0]);
        message.reply({content: `Adding ${res.tracks[0].title} to the queue`})
        if (!player.playing && !player.paused && !player.queue.size) player.play();
    }  
})