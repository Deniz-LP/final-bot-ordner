const Command = require("../../struct/Commands");
module.exports = new Command({
    name: 'loopqueue',
    aliases: ['loop'],
    description: 'loops the queue',
    usage: '<>',
    cd: 10,
    async run (message, args, client) {
        //here will run the command
        let pl = client.music.manager.get(message.guild.id);
        if (!pl) return message.reply('Put some songs')
        let bool = pl?.queueRepeat;
        bool = !bool
        pl.setQueueRepeat(bool)
        if (bool) message.channel.send('The queue will now repeat 🔁');
        if (!bool) message.channel.send('The queue will now not be repeated 🔂');
    }  
})