const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");
const Command = require("../../struct/Commands");
module.exports = new Command({
    name: 'queue',
    aliases: ['q'],
    description: 'see queue',
    usage: '<>',
    cd: 10,
    async run (message, args, client) {
        //here will run the command
        let pl = client.music.manager.get(message.guild.id);
        if (!pl || !pl?.queue?.size) return message.reply('Put some songs')
        let q = Array.from(pl.queue)
        q.forEach((n, i)=> n.index = i+1);
        let queue = client.utils.chunk(q, 10)

        let row = new MessageActionRow()
        .addComponents(
            new MessageButton()
            .setCustomId('back')
            .setStyle('PRIMARY')
            .setEmoji('⬅️')
        )
        .addComponents(
            new MessageButton()
            .setCustomId('next')
            .setStyle('PRIMARY')
            .setEmoji('➡️')
        )

        let embed = new MessageEmbed()
        embed.setTitle('Queue')
        embed.setColor('RANDOM')
        embed.setDescription(queue[0].map(song => `**[${song.index}]** [${song.title}](${song.uri}) | ${song.requester.username}`).join('\n'))
        embed.setFooter({text: `Page: ${1}/${queue.length}`})

        let msg = await message.reply({embeds: [embed], components:[row]})

        const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 60000
        })
        let num = 0;
        collector.on('collect', (btn)=> {
            btn.deferUpdate();
            if (btn.customId === 'back') num--
            if (btn.customId === 'next') num++
            num = ((num % queue.length) + queue.length) % queue.length
            embed.setDescription(queue[num].map(song => `**[${song.index}]** [${song.title}](${song.uri}) | ${song.requester.username}`).join('\n'))
            embed.setFooter({text: `Page: ${num+1}/${queue.length}`})
            msg.edit({embeds: [embed]})
        })

        collector.on('end', ()=> msg.edit({components: []}))
        

    }  
})