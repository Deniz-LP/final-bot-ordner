const Command = require("../../struct/Commands");
module.exports = new Command({
    name: 'stop',
    aliases: ['l'],
    description: 'stops the bot',
    usage: '<>',
    cd: 10,
    async run (message, args, client) {
        //here will run the command
        let pl = client.music.manager.get(message.guild.id);
        if (!pl) return message.reply({content: 'There is nothing to stop'});
        pl.queue.clear();
        pl.stop()
    }  
})