const path = require('path')
const {promisify} = require('util')
const glob = require('glob')
const Event = require('../struct/Events')
const Command = require('../struct/Commands')
const globPromise = promisify(glob)
module.exports = class Utils {
    constructor(client) {
        this.client = client;
    }


    get directory() {
        return `${path.dirname(require.main.filename)}${path.sep}`;
    }

    chunk(array, size) {
		const chunked_arr = [];
		for (let i = 0; i < array.length; i+=size) {
			chunked_arr.push(array.slice(i, i + size));
		}
		return chunked_arr;
	}
    parseMs(milliseconds) {
    
        const roundTowardsZero = milliseconds > 0 ? Math.floor : Math.ceil;
    
        return {
            days: roundTowardsZero(milliseconds / 86400000),
            hours: roundTowardsZero(milliseconds / 3600000) % 24,
            minutes: roundTowardsZero(milliseconds / 60000) % 60,
            seconds: roundTowardsZero(milliseconds / 1000) % 60,
            milliseconds: roundTowardsZero(milliseconds) % 1000,
            microseconds: roundTowardsZero(milliseconds * 1000) % 1000,
            nanoseconds: roundTowardsZero(milliseconds * 1e6) % 1000
        };
    }


    async loadCommands() {
       const commands = await globPromise(`${this.directory}Commands/**/*.js`.replace(/\\/g, '/'))
       for (const commandFile of commands) {
           delete require.cache[commandFile]
           const {name} = path.parse(commandFile)
           const command = require(commandFile)
           if (!command instanceof Command) throw new TypeError(`Command ${name} is not a valid command`)
           this.client.commands.set(command.name, command)
           if (command.aliases.length) {
               for (const alias of command.aliases) {
                   this.client.aliases.set(alias, command.name)
               }
           }
       }
    }

    async loadEvents() {
        const events = await globPromise(`${this.directory}events/**/*.js`.replace(/\\/g, '/'))
        for (const eventFile of events) {
            delete require.cache[eventFile]
            const {name} = path.parse(eventFile)
            const File = require(eventFile)
            const event = new File(this.client, name.toLocaleLowerCase())
            if (!(event instanceof Event)) throw new TypeError(`This is a bad class`)
            this.client.events.set(event.name, event);
            event.emmiter[event.type](name, (...args)=> event.run(...args))
        }
    }
    
}